﻿// Файл: TaskPlanner.Tests/ProjectManagerTests.cs
// ВЕРСІЯ 2.0 (Підтримує нову логіку з List<int> ExecutorIds)

using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq; // <-- Наша бібліотека "моків"
using TaskPlanner.BLL.Interfaces;
using TaskPlanner.BLL.Models;
using TaskPlanner.BLL.Services;
using System.Collections.Generic;
using System.Linq;

// Псевдоніми для уникнення конфліктів
using Task = TaskPlanner.BLL.Models.Task;

namespace TaskPlanner.Tests
{
    [TestClass] // Атрибут, який каже, що це клас з тестами
    public class ProjectManagerTests
    {
        // "Мок" (фальшивий) репозиторій
        private Mock<IRepository> _mockRepository = null!;

        // Наш "мозок", який ми тестуємо
        private ProjectManager _projectManager = null!;

        // Наша "фальшива" база даних у пам'яті
        private List<Executor> _executorDatabase = null!;
        private List<Task> _taskDatabase = null!;

        [TestInitialize] // Цей метод запускається ПЕРЕД кожним тестом
        public void Setup()
        {
            // --- ARRANGE (Підготовка) ---
            // Це частина принципу "Triple A", яка готує середовище

            // 1. Створюємо фальшиві списки
            _executorDatabase = new List<Executor>();
            _taskDatabase = new List<Task>();

            // 2. Створюємо "мок" для IRepository
            _mockRepository = new Mock<IRepository>();

            // 3. Навчаємо "мок", як поводитися:

            // Коли BLL просить "GetAllExecutors", поверни наш фальшивий список
            _mockRepository.Setup(r => r.GetAllExecutors())
                           .Returns(_executorDatabase);

            // Коли BLL просить "GetAllTasks", поверни наш фальшивий список
            _mockRepository.Setup(r => r.GetAllTasks())
                           .Returns(_taskDatabase);

            // Коли BLL просить "SaveExecutors"...
            _mockRepository.Setup(r => r.SaveExecutors(It.IsAny<IEnumerable<Executor>>()))
                           .Callback((IEnumerable<Executor> executors) => {
                               _executorDatabase.Clear(); // ...очисти "базу"...
                               _executorDatabase.AddRange(executors); // ...і додай нові дані
                           });

            // Те саме для завдань
            _mockRepository.Setup(r => r.SaveTasks(It.IsAny<IEnumerable<Task>>()))
                          .Callback((IEnumerable<Task> tasks) => {
                              _taskDatabase.Clear();
                              _taskDatabase.AddRange(tasks);
                          });

            // 4. Створюємо ProjectManager, передаючи йому ФАЛЬШИВИЙ репозиторій
            _projectManager = new ProjectManager(_mockRepository.Object);
        }

        [TestMethod] // Тест 1
        public void AddExecutor_ValidData_ShouldAddExecutor()
        {
            // Arrange (Готово у Setup)

            // Act (Дія)
            var newExecutor = _projectManager.AddExecutor("Іван", "Козак", "Розробник");

            // Assert (Перевірка)
            Assert.IsNotNull(newExecutor);
            Assert.AreEqual(1, newExecutor.Id); // Має бути 1-й ID
            // Перевіряємо, що він реально з'явився у "базі"
            Assert.AreEqual(1, _projectManager.GetAllExecutors().Count());
        }

        [TestMethod] // Тест 2
        public void AddExecutor_InvalidData_ShouldThrowException()
        {
            // Arrange (Готово у Setup)

            // Act & Assert
            // Перевіряємо, що BLL кидає виняток (Exception) при спробі
            // створити виконавця з пустим ім'ям (тест валідації)
            Assert.ThrowsException<ArgumentException>(() => {
                _projectManager.AddExecutor("", "Козак", "Розробник");
            });
        }

        [TestMethod] // Тест 3
        public void DeleteExecutor_ExistingId_ShouldUnassignFromTasks()
        {
            // Arrange
            // Додаємо виконавця 1 і завдання 1
            var executor = _projectManager.AddExecutor("Тест", "Видалення", "Тестер");
            var task = _projectManager.AddTask("Тест Завдання", "...", DateTime.Now);

            // Призначаємо його (тестуємо нову логіку)
            _projectManager.AssignTaskToExecutor(task.Id, executor.Id);

            // Перевірка: він 100% призначений
            Assert.AreEqual(1, task.ExecutorIds.Count);

            // Act (Дія)
            // Видаляємо виконавця
            bool result = _projectManager.DeleteExecutor(executor.Id);

            // Assert (Перевірка)
            Assert.IsTrue(result);
            // Перевіряємо, що виконавець зник зі списку
            Assert.AreEqual(0, _projectManager.GetAllExecutors().Count());
            // НАЙГОЛОВНІШЕ: Перевіряємо, що він зник зі списку завдання
            Assert.AreEqual(0, task.ExecutorIds.Count);
        }

        [TestMethod] // Тест 4 (Тестуємо нову логіку "багато-до-багатьох")
        public void AssignTaskToExecutor_MultipleExecutors_ShouldAddAll()
        {
            // Arrange
            var exec1 = _projectManager.AddExecutor("Іван", "Козак", "Розробник"); // ID 1
            var exec2 = _projectManager.AddExecutor("Тетяна", "Постернак", "Менеджер"); // ID 2
            var task = _projectManager.AddTask("Велике Завдання", "...", DateTime.Now); // ID 1

            // Act
            _projectManager.AssignTaskToExecutor(task.Id, exec1.Id);
            _projectManager.AssignTaskToExecutor(task.Id, exec2.Id); // Додаємо другого

            // Assert
            var resultTask = _projectManager.GetTaskById(task.Id);
            Assert.IsNotNull(resultTask);
            // Перевіряємо, що у списку їх ДВОЄ (доказ нової логіки)
            Assert.AreEqual(2, resultTask.ExecutorIds.Count);
            Assert.IsTrue(resultTask.ExecutorIds.Contains(exec1.Id));
            Assert.IsTrue(resultTask.ExecutorIds.Contains(exec2.Id));
        }

        [TestMethod] // Тест 5 (Тестуємо нову логіку пошуку)
        public void GetExecutorsOfTask_ValidTaskId_ShouldReturnCorrectList()
        {
            // Arrange
            var exec1 = _projectManager.AddExecutor("Іван", "Козак", "Розробник");
            var exec2 = _projectManager.AddExecutor("Тетяна", "Постернак", "Менеджер");
            var exec3 = _projectManager.AddExecutor("Інший", "Чоловік", "Тестер"); // Не буде призначений

            var task = _projectManager.AddTask("Велике Завдання", "...", DateTime.Now);

            _projectManager.AssignTaskToExecutor(task.Id, exec1.Id);
            _projectManager.AssignTaskToExecutor(task.Id, exec2.Id);

            // Act
            // Викликаємо метод 4.2
            var executors = _projectManager.GetExecutorsOfTask(task.Id).ToList();

            // Assert
            Assert.AreEqual(2, executors.Count); // Має бути 2, а не 3
            Assert.IsTrue(executors.Any(e => e.FirstName == "Іван"));
            Assert.IsTrue(executors.Any(e => e.FirstName == "Тетяна"));
            Assert.IsFalse(executors.Any(e => e.FirstName == "Інший")); // Перевірка, що зайвого немає
        }
    }
}