﻿// Файл: TaskPlanner.PL/Program.cs
// --- ВЕРСІЯ 4.0 (Фінальна, підтримує багатьох виконавців) ---

using TaskPlanner.BLL.Enums;
using TaskPlanner.BLL.Interfaces;
using TaskPlanner.BLL.Models;
using TaskPlanner.BLL.Services;
using TaskPlanner.DAL;
using System;
using System.Collections.Generic; // <-- Додано
using System.Linq;

// Псевдоніми
using Task = TaskPlanner.BLL.Models.Task;
using TaskStatus = TaskPlanner.BLL.Enums.TaskStatus;

// --- Головна частина програми ---

Console.OutputEncoding = System.Text.Encoding.UTF8;
Console.InputEncoding = System.Text.Encoding.UTF8;

IRepository fileRepository = new FileRepository();
ProjectManager manager = new ProjectManager(fileRepository);

Console.WriteLine("--- Ласкаво просимо у Планувальник Завдань! (v4.0) ---");

bool isRunning = true;
while (isRunning)
{
    ShowMainMenu(); // Меню оновлено
    string? choice = Console.ReadLine();

    try
    {
        switch (choice)
        {
            // === 1. Управління членами команди ===
            case "1":
                AddNewExecutor(); // 1.1 Додати
                break;
            case "2":
                DeleteExecutorMenu(); // 1.2 Видалити
                break;
            case "3":
                UpdateExecutorMenu(); // 1.3 Змінити
                break;
            case "4":
                ShowAllExecutors(); // 1.4 Переглянути
                break;

            // === 2. Управління завданнями ===
            case "5":
                AddNewTask(); // 2.1 Додати
                break;
            case "6":
                DeleteTaskMenu(); // 2.2 Видалити
                break;
            case "7":
                UpdateTaskMenu(); // 2.3 Змінити
                break;
            case "8":
                ShowAllTasks(); // 2.4 Переглянути
                break;

            // === 3. Управління розподілом ===
            case "9":
                AddExecutorToTaskMenu(); // 3.1 Призначити (ОНОВЛЕНО)
                break;
            case "10":
                RemoveExecutorFromTaskMenu(); // 3.1 Зняти (НОВИЙ)
                break;
            case "11":
                ChangeTaskStatus(); // 3.2 Змінити статус
                break;
            case "12":
                ShowExecutorWorkload(); // 3.4 Завантаженість
                break;
            case "13":
                ShowProjectStatus(); // 3.5 Статус проекту
                break;

            // === 4. Пошук ===
            case "14":
                FindTasksForExecutorMenu(); // 4.1 Завдання виконавця
                break;
            case "15":
                FindExecutorsForTaskMenu(); // 4.2 Виконавці завдання (ОНОВЛЕНО)
                break;
            case "16":
                ShowTasksByDeadlineMenu(); // 3.3/4.3 Пошук за терміном (ОНОВЛЕНО)
                break;
            case "17":
                ShowTasksByStatusMenu(); // 2.5/4.3 Пошук за статусом
                break;
            case "18":
                ComplexSearchMenu(); // 4.3 Складний пошук (НОВИЙ)
                break;

            // === Вихід ===
            case "0":
                isRunning = false;
                Console.WriteLine("Дякуємо за використання! Дані збережено.");
                break;
            default:
                Console.WriteLine("ПОМИЛКА: Невідома команда. Спробуйте ще раз.");
                break;
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"!!! ВИНИКЛА ПОМИЛКА BLL: {ex.Message}");
    }

    if (isRunning)
    {
        Console.WriteLine("\nНатисніть будь-яку клавішу для повернення в меню...");
        Console.ReadKey();
    }
}

// === МЕТОДИ ІНТЕРФЕЙСУ (Presentation Layer) ===

void ShowMainMenu() // <-- ПОВНІСТЮ ОНОВЛЕНЕ МЕНЮ
{
    Console.Clear();
    Console.WriteLine("--- Планувальник Завдань ---");

    Console.WriteLine("\n--- 1. Управління Командою ---");
    Console.WriteLine("1. Додати виконавця ");
    Console.WriteLine("2. Видалити виконавця ");
    Console.WriteLine("3. Змінити дані про виконавця ");
    Console.WriteLine("4. Показати всіх виконавців ");

    Console.WriteLine("\n--- 2. Управління Завданнями ---");
    Console.WriteLine("5. Додати завдання ");
    Console.WriteLine("6. Видалити завдання ");
    Console.WriteLine("7. Змінити дані про завдання ");
    Console.WriteLine("8. Показати всі завдання ");

    Console.WriteLine("\n--- 3. Управління Процесом ---");
    Console.WriteLine("9. Призначити виконавця завданню ");
    Console.WriteLine("10. Зняти виконавця з завдання ");
    Console.WriteLine("11. Змінити статус завдання ");
    Console.WriteLine("12. Показати завантаженість виконавця ");
    Console.WriteLine("13. Отримати статус проекту (%) ");

    Console.WriteLine("\n--- 4. Пошук ---");
    Console.WriteLine("14. Знайти завдання за виконавцем )");
    Console.WriteLine("15. Знайти виконавців за завданням ");
    Console.WriteLine("16. Пошук за терміном (триває/закінчився) ");
    Console.WriteLine("17. Пошук за статусом (викон/невикон) ");
    Console.WriteLine("18. Складний пошук (статус + термін) ");

    Console.WriteLine("\n---------------------------------");
    Console.WriteLine("0. Вихід та збереження");
    Console.Write("Ваш вибір: ");
}

//
// --- Методи-обробники ---
// (Деякі оновлено, деякі додано)
//

// === 1. Команда ===
void AddNewExecutor()
{
    Console.WriteLine("\n--- Додавання Виконавця ---");
    Console.Write("Введіть Ім'я: ");
    string firstName = Console.ReadLine() ?? "";
    Console.Write("Введіть Прізвище: ");
    string lastName = Console.ReadLine() ?? "";
    Console.Write("Введіть Посаду: ");
    string position = Console.ReadLine() ?? "";
    var newExecutor = manager.AddExecutor(firstName, lastName, position);
    Console.WriteLine($"УСПІХ: Створено {newExecutor}");
}

void DeleteExecutorMenu()
{
    Console.WriteLine("\n--- Видалення Виконавця ---");
    ShowAllExecutors();
    Console.Write("\nВведіть ID виконавця для видалення: ");
    if (!int.TryParse(Console.ReadLine(), out int executorId))
    {
        Console.WriteLine("ПОМИЛКА: Це не число.");
        return;
    }
    bool success = manager.DeleteExecutor(executorId);
    if (success) Console.WriteLine($"УСПІХ: Виконавець з ID {executorId} видалений (та знятий з усіх завдань).");
    else Console.WriteLine("ПОМИЛКА: Виконавця з таким ID не знайдено.");
}

void UpdateExecutorMenu()
{
    Console.WriteLine("\n--- Зміна Даних Виконавця ---");
    ShowAllExecutors();
    Console.Write("\nВведіть ID виконавця для оновлення: ");
    if (!int.TryParse(Console.ReadLine(), out int executorId))
    {
        Console.WriteLine("ПОМИЛКА: Це не число.");
        return;
    }
    var executor = manager.GetExecutorById(executorId);
    if (executor == null)
    {
        Console.WriteLine("ПОМИЛКА: Виконавця не знайдено.");
        return;
    }
    Console.WriteLine($"Поточні дані: {executor}");
    Console.Write($"Нове ім'я (Enter, щоб лишити '{executor.FirstName}'): ");
    string newFirstName = Console.ReadLine() ?? "";
    Console.Write($"Нове прізвище (Enter, щоб лишити '{executor.LastName}'): ");
    string newLastName = Console.ReadLine() ?? "";
    Console.Write($"Нова посада (Enter, щоб лишити '{executor.Position}'): ");
    string newPosition = Console.ReadLine() ?? "";
    manager.UpdateExecutor(executorId, newFirstName, newLastName, newPosition);
    Console.WriteLine("УСПІХ: Дані виконавця оновлено.");
}

void ShowAllExecutors()
{
    Console.WriteLine("\n--- Список Виконавців ---");
    var executors = manager.GetAllExecutors();
    if (!executors.Any())
    {
        Console.WriteLine("Список порожній.");
        return;
    }
    foreach (var executor in executors) Console.WriteLine(executor);
}

// === 2. Завдання ===
void AddNewTask()
{
    Console.WriteLine("\n--- Додавання Завдання ---");
    Console.Write("Назва завдання: ");
    string title = Console.ReadLine() ?? "";
    Console.Write("Опис: ");
    string description = Console.ReadLine() ?? "";
    DateTime deadline;
    while (true)
    {
        Console.Write("Дедлайн (дд.мм.рррр): ");
        if (DateTime.TryParse(Console.ReadLine(), out deadline))
        {
            break;
        }
        Console.WriteLine("ПОМИЛКА: Некоректний формат дати.");
    }
    var newTask = manager.AddTask(title, description, deadline);
    Console.WriteLine($"УСПІХ: Створено {newTask}");
}

void DeleteTaskMenu()
{
    Console.WriteLine("\n--- Видалення Завдання ---");
    ShowAllTasks();
    Console.Write("\nВведіть ID завдання для видалення: ");
    if (!int.TryParse(Console.ReadLine(), out int taskId))
    {
        Console.WriteLine("ПОМИЛКА: Це не число.");
        return;
    }
    bool success = manager.DeleteTask(taskId);
    if (success) Console.WriteLine($"УСПІХ: Завдання з ID {taskId} видалено.");
    else Console.WriteLine("ПОМИЛКА: Завдання з таким ID не знайдено.");
}

void UpdateTaskMenu()
{
    Console.WriteLine("\n--- Зміна Даних Завдання ---");
    ShowAllTasks();
    Console.Write("\nВведіть ID завдання для оновлення: ");
    if (!int.TryParse(Console.ReadLine(), out int taskId))
    {
        Console.WriteLine("ПОМИЛКА: Це не число.");
        return;
    }
    var task = manager.GetTaskById(taskId);
    if (task == null)
    {
        Console.WriteLine("ПОМИЛКА: Завдання не знайдено.");
        return;
    }
    Console.WriteLine($"Поточні дані: {task}");
    Console.Write($"Нова назва (Enter, щоб лишити '{task.Title}'): ");
    string newTitle = Console.ReadLine() ?? "";
    Console.Write($"Новий опис (Enter, щоб лишити '{task.Description}'): ");
    string newDescription = Console.ReadLine() ?? "";
    DateTime newDeadline = task.Deadline;
    Console.Write($"Новий дедлайн (дд.мм.рррр) (Enter, щоб лишити '{task.Deadline.ToShortDateString()}'): ");
    string? deadlineInput = Console.ReadLine();
    if (!string.IsNullOrWhiteSpace(deadlineInput))
    {
        if (!DateTime.TryParse(deadlineInput, out newDeadline))
        {
            Console.WriteLine("ПОМИЛКА: Некоректний формат дати. Дедлайн не змінено.");
            newDeadline = task.Deadline;
        }
    }
    manager.UpdateTask(taskId, newTitle, newDescription, newDeadline);
    Console.WriteLine("УСПІХ: Дані завдання оновлено.");
}

void ShowAllTasks()
{
    Console.WriteLine("\n--- Список Всіх Завдань ---");
    var tasks = manager.GetAllTasks();
    if (!tasks.Any())
    {
        Console.WriteLine("Немає завдань.");
        return;
    }
    foreach (var task in tasks) Console.WriteLine(task);
}

// === 3. Процес ===

void AddExecutorToTaskMenu() // ОНОВЛЕНО (раніше 'AssignTask')
{
    Console.WriteLine("\n--- Призначити Виконавця Завданню ---");
    Console.WriteLine("Доступні завдання:");
    ShowAllTasks();
    Console.WriteLine("\nДоступні виконавці:");
    ShowAllExecutors();

    Console.Write("\nВведіть ID завдання: ");
    if (!int.TryParse(Console.ReadLine(), out int taskId))
    {
        Console.WriteLine("ПОМИЛКА: Це не число.");
        return;
    }
    Console.Write("Введіть ID виконавця, якого треба ДОДАТИ: ");
    if (!int.TryParse(Console.ReadLine(), out int executorId))
    {
        Console.WriteLine("ПОМИЛКА: Це не число.");
        return;
    }

    // Викликаємо оновлений BLL
    bool success = manager.AssignTaskToExecutor(taskId, executorId);
    if (success) Console.WriteLine("УСПІХ: Виконавця додано до завдання!");
    else Console.WriteLine("ПОМИЛКА: Не вдалося додати. Можливо, він вже призначений, або ID невірні.");
}

void RemoveExecutorFromTaskMenu() // НОВИЙ МЕТОД
{
    Console.WriteLine("\n--- Зняти Виконавця з Завдання ---");
    Console.WriteLine("Доступні завдання:");
    ShowAllTasks();

    Console.Write("\nВведіть ID завдання: ");
    if (!int.TryParse(Console.ReadLine(), out int taskId))
    {
        Console.WriteLine("ПОМИЛКА: Це не число.");
        return;
    }

    var task = manager.GetTaskById(taskId);
    if (task == null)
    {
        Console.WriteLine("ПОМИЛКА: Завдання не знайдено.");
        return;
    }

    Console.WriteLine("Виконавці на цьому завданні:");
    var executorsOnTask = manager.GetExecutorsOfTask(taskId);
    if (!executorsOnTask.Any())
    {
        Console.WriteLine("На цьому завданні немає виконавців.");
        return;
    }
    foreach (var exec in executorsOnTask) Console.WriteLine(exec);

    Console.Write("\nВведіть ID виконавця, якого треба ЗНЯТИ: ");
    if (!int.TryParse(Console.ReadLine(), out int executorId))
    {
        Console.WriteLine("ПОМИЛКА: Це не число.");
        return;
    }

    // Викликаємо BLL
    bool success = manager.RemoveExecutorFromTask(taskId, executorId);
    if (success) Console.WriteLine("УСПІХ: Виконавця знято з завдання!");
    else Console.WriteLine("ПОМИЛКА: Не вдалося зняти. Перевірте ID.");
}

void ChangeTaskStatus()
{
    Console.WriteLine("\n--- Зміна Статусу Завдання ---");
    ShowAllTasks();
    Console.Write("\nВведіть ID завдання: ");
    if (!int.TryParse(Console.ReadLine(), out int taskId))
    {
        Console.WriteLine("ПОМИЛКА: Це не число.");
        return;
    }
    var task = manager.GetTaskById(taskId);
    if (task == null)
    {
        Console.WriteLine("ПОМИЛКА: Завдання з таким ID не знайдено.");
        return;
    }
    Console.WriteLine($"Поточний статус: {task.Status}");
    Console.WriteLine("Оберіть новий статус: 1. New, 2. InProgress, 3. Done");
    Console.Write("Ваш вибір (1-3): ");
    string? statusChoice = Console.ReadLine();
    TaskStatus newStatus;
    switch (statusChoice)
    {
        case "1": newStatus = TaskStatus.New; break;
        case "2": newStatus = TaskStatus.InProgress; break;
        case "3": newStatus = TaskStatus.Done; break;
        default: Console.WriteLine("ПОМИЛКА: Невірний вибір."); return;
    }
    bool success = manager.ChangeTaskStatus(taskId, newStatus);
    if (success) Console.WriteLine($"УСПІХ: Статус завдання {taskId} змінено на {newStatus}");
    else Console.WriteLine("ПОМИЛКА: Не вдалося змінити статус.");
}

void ShowExecutorWorkload()
{
    Console.WriteLine("\n--- Завантаженість Виконавців ---");
    ShowAllExecutors();
    Console.Write("\nВведіть ID виконавця: ");
    if (!int.TryParse(Console.ReadLine(), out int executorId))
    {
        Console.WriteLine("ПОМИЛКА: Це не число.");
        return;
    }
    try
    {
        int workload = manager.GetExecutorWorkload(executorId);
        var executor = manager.GetExecutorById(executorId);
        Console.WriteLine($"УСПІХ: Виконавець '{executor?.FirstName}' має {workload} активних завдань.");
    }
    catch (Exception ex)
    {
        Console.WriteLine($"ПОМИЛКА: {ex.Message}");
    }
}

void ShowProjectStatus()
{
    Console.WriteLine("\n--- Загальний Статус Проекту ---");
    string status = manager.GetProjectStatus();
    Console.WriteLine(status);
}

// === 4. Пошук ===

void FindTasksForExecutorMenu()
{
    Console.WriteLine("\n--- Пошук Завдань за Виконавцем ---");
    ShowAllExecutors();
    Console.Write("\nВведіть ID виконавця: ");
    if (!int.TryParse(Console.ReadLine(), out int executorId))
    {
        Console.WriteLine("ПОМИЛКА: Це не число.");
        return;
    }
    try
    {
        var tasks = manager.GetTasksForExecutor(executorId);
        if (!tasks.Any())
        {
            Console.WriteLine("У цього виконавця немає завдань.");
            return;
        }
        Console.WriteLine($"\n--- Завдання для виконавця ID {executorId} ---");
        foreach (var task in tasks) Console.WriteLine(task);
    }
    catch (Exception ex)
    {
        Console.WriteLine($"ПОМИЛКА: {ex.Message}");
    }
}

void FindExecutorsForTaskMenu() // ОНОВЛЕНО
{
    Console.WriteLine("\n--- Пошук Виконавців за Завданням ---");
    ShowAllTasks();
    Console.Write("\nВведіть ID завдання: ");
    if (!int.TryParse(Console.ReadLine(), out int taskId))
    {
        Console.WriteLine("ПОМИЛКА: Це не число.");
        return;
    }
    try
    {
        // BLL тепер повертає список!
        var executors = manager.GetExecutorsOfTask(taskId);
        if (!executors.Any())
        {
            Console.WriteLine("Це завдання нікому не призначене.");
        }
        else
        {
            Console.WriteLine($"\nЗавдання {taskId} виконують:");
            foreach (var executor in executors)
            {
                Console.WriteLine(executor); // Друкуємо список
            }
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"ПОМИЛКА: {ex.Message}");
    }
}

void ShowTasksByDeadlineMenu() // ОНОВЛЕНО (раніше 'ShowExpiredTasks')
{
    Console.WriteLine("\n--- Пошук Завдань за Терміном ---");
    Console.WriteLine("1. Показати протерміновані ('закінчився')");
    Console.WriteLine("2. Показати актуальні ('триває')");
    Console.Write("Ваш вибір: ");
    string? choice = Console.ReadLine();

    IEnumerable<Task> tasks;
    if (choice == "1")
    {
        // isDone: false (невиконані), isExpired: true (протерміновані)
        tasks = manager.SearchTasks(isDone: false, isExpired: true);
        Console.WriteLine("\n--- Протерміновані Невиконані Завдання ---");
    }
    else if (choice == "2")
    {
        // isDone: false (невиконані), isExpired: false (актуальні)
        tasks = manager.SearchTasks(isDone: false, isExpired: false);
        Console.WriteLine("\n--- Актуальні Невиконані Завдання ('триває') ---");
    }
    else
    {
        Console.WriteLine("ПОМИЛКА: Невірний вибір.");
        return;
    }

    if (!tasks.Any())
    {
        Console.WriteLine("Завдань за цим фільтром немає.");
        return;
    }
    foreach (var task in tasks) Console.WriteLine(task);
}

void ShowTasksByStatusMenu()
{
    Console.WriteLine("\n--- Пошук Завдань за Статусом ---");
    Console.WriteLine("1. Показати виконані (Done)");
    Console.WriteLine("2. Показати невиконані (New, InProgress)");
    Console.Write("Ваш вибір: ");
    string? choice = Console.ReadLine();

    IEnumerable<Task> tasks;
    if (choice == "1")
    {
        tasks = manager.GetTasksByStatus(true); // Хочемо виконані
        Console.WriteLine("\n--- Виконані Завдання ---");
    }
    else if (choice == "2")
    {
        tasks = manager.GetTasksByStatus(false); // Хочемо невиконані
        Console.WriteLine("\n--- Невиконані Завдання ---");
    }
    else
    {
        Console.WriteLine("ПОМИЛКА: Невірний вибір.");
        return;
    }

    if (!tasks.Any())
    {
        Console.WriteLine("Завдань за цим фільтром немає.");
        return;
    }
    foreach (var task in tasks) Console.WriteLine(task);
}

void ComplexSearchMenu() // НОВИЙ МЕТОД
{
    Console.WriteLine("\n--- Складний Пошук ---");

    // 1. Обираємо Статус
    Console.WriteLine("Оберіть статус:");
    Console.WriteLine("1. Виконані (Done)");
    Console.WriteLine("2. Невиконані (New, InProgress)");
    Console.Write("Ваш вибір (1-2): ");
    string? statusChoice = Console.ReadLine();
    bool isDone;

    if (statusChoice == "1") isDone = true;
    else if (statusChoice == "2") isDone = false;
    else { Console.WriteLine("ПОМИЛКА: Невірний вибір."); return; }

    // 2. Обираємо Термін
    Console.WriteLine("Оберіть термін:");
    Console.WriteLine("1. Протерміновані ('закінчився')");
    Console.WriteLine("2. Актуальні ('триває')");
    Console.Write("Ваш вибір (1-2): ");
    string? deadlineChoice = Console.ReadLine();
    bool isExpired;

    if (deadlineChoice == "1") isExpired = true;
    else if (deadlineChoice == "2") isExpired = false;
    else { Console.WriteLine("ПОМИЛКА: Невірний вибір."); return; }

    // 3. Викликаємо BLL
    var tasks = manager.SearchTasks(isDone, isExpired);

    Console.WriteLine($"\n--- Результати Пошуку (Статус: {(isDone ? "Виконані" : "Невиконані")}, Термін: {(isExpired ? "Протерміновані" : "Актуальні")}) ---");
    if (!tasks.Any())
    {
        Console.WriteLine("Завдань за цим фільтром немає.");
        return;
    }
    foreach (var task in tasks) Console.WriteLine(task);
}