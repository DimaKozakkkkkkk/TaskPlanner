﻿// Файл: TaskPlanner.BLL/Models/Task.cs
// ВЕРСІЯ 2.0 (Підтримує багатьох виконавців)

using TaskPlanner.BLL.Enums;
using Newtonsoft.Json;
using System.Collections.Generic; // <-- Потрібно для List
using System.Linq; // <-- Потрібно для .Any()

// Псевдонім для уникнення конфлікту
using TaskStatus = TaskPlanner.BLL.Enums.TaskStatus;

namespace TaskPlanner.BLL.Models
{
    public class Task
    {
        public int Id { get; private set; }
        public string Title { get; private set; }
        public string Description { get; private set; }
        public DateTime Deadline { get; private set; }
        public TaskStatus Status { get; private set; }

        // === ГОЛОВНА ЗМІНА ===
        // Замість 'int? ExecutorId' тепер список
        public List<int> ExecutorIds { get; private set; }

        [JsonConstructor]
        public Task(int id, string title, string description, DateTime deadline)
        {
            if (id <= 0)
                throw new ArgumentException("ID має бути додатнім.", nameof(id));
            if (string.IsNullOrWhiteSpace(title))
                throw new ArgumentException("Назва не може бути пустою.", nameof(title));

            Id = id;
            Title = title;
            Description = description;
            Deadline = deadline;
            Status = TaskStatus.New;

            // Ініціалізуємо порожній список
            ExecutorIds = new List<int>();
        }

        public void UpdateTask(string newTitle, string newDescription, DateTime newDeadline)
        {
            if (!string.IsNullOrWhiteSpace(newTitle))
                Title = newTitle;
            if (!string.IsNullOrWhiteSpace(newDescription))
                Description = newDescription;
            if (newDeadline > DateTime.Now)
                Deadline = newDeadline;
        }

        // --- Оновлені методи для роботи зі списком ---

        // Метод для ДОДАВАННЯ виконавця
        public bool AddExecutor(int executorId)
        {
            if (executorId <= 0)
                throw new ArgumentException("Некоректний ID виконавця.", nameof(executorId));

            // Перевірка, щоб не додати двічі
            if (!ExecutorIds.Contains(executorId))
            {
                ExecutorIds.Add(executorId);
                if (Status == TaskStatus.New) // Авто-переведення в роботу
                    Status = TaskStatus.InProgress;
                return true;
            }
            return false; // Вже був призначений
        }

        // Метод для ВИДАЛЕННЯ виконавця
        public bool RemoveExecutor(int executorId)
        {
            bool success = ExecutorIds.Remove(executorId);
            // Якщо це був останній виконавець, можна змінити статус?
            // (поки що не будемо)
            return success;
        }

        public void ChangeStatus(TaskStatus newStatus)
        {
            Status = newStatus;
        }

        public bool IsExpired()
        {
            return Status != TaskStatus.Done && Deadline < DateTime.Now;
        }

        public override string ToString()
        {
            // Оновлений ToString, щоб показувати кількість виконавців
            string executorInfo;
            if (!ExecutorIds.Any()) // .Any() - метод LINQ
            {
                executorInfo = " (Не призначено)";
            }
            else
            {
                executorInfo = $" (Призначено: {ExecutorIds.Count} виконавцям)";
            }

            string statusInfo = IsExpired() ? "ПРОТЕРМІНОВАНО" : Status.ToString();
            return $"[{Id}] {Title} (До: {Deadline.ToShortDateString()}) - {statusInfo}{executorInfo}";
        }
    }
}