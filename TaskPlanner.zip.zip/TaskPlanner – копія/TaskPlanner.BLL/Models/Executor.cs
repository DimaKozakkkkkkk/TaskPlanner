﻿// Файл: TaskPlanner.BLL/Models/Executor.cs
using Newtonsoft.Json; // <-- ДОДАНО

namespace TaskPlanner.BLL.Models
{
    public class Executor
    {
        public int Id { get; private set; }
        public string FirstName { get; private set; }
        public string LastName { get; private set; }
        public string Position { get; private set; }

        [JsonConstructor] // <-- ДОДАНО
        public Executor(int id, string firstName, string lastName, string position)
        {
            if (id <= 0)
                throw new ArgumentException("ID має бути додатнім.", nameof(id));
            if (string.IsNullOrWhiteSpace(firstName))
                throw new ArgumentException("Ім'я не може бути пустим.", nameof(firstName));

            Id = id;
            FirstName = firstName;
            LastName = lastName;
            Position = position;
        }

        public void UpdateInfo(string newFirstName, string newLastName, string newPosition)
        {
            if (!string.IsNullOrWhiteSpace(newFirstName))
                FirstName = newFirstName;
            if (!string.IsNullOrWhiteSpace(newLastName))
                LastName = newLastName;
            if (!string.IsNullOrWhiteSpace(newPosition))
                Position = newPosition;
        }

        public override string ToString()
        {
            return $"[{Id}] {FirstName} {LastName} ({Position})";
        }
    }
}