﻿// Файл: TaskPlanner.BLL/Enums/TaskStatus.cs
namespace TaskPlanner.BLL.Enums
{
    public enum TaskStatus
    {
        New,
        InProgress,
        Done
    }
}