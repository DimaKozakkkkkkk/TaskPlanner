﻿// Файл: TaskPlanner.BLL/Interfaces/IRepository.cs
using TaskPlanner.BLL.Models;


using Task = TaskPlanner.BLL.Models.Task;

namespace TaskPlanner.BLL.Interfaces
{
    public interface IRepository
    {
        // Тепер C# знає, що це наш Task
        IEnumerable<Task> GetAllTasks();

        IEnumerable<Executor> GetAllExecutors();

        // І тут він теж знає
        void SaveTasks(IEnumerable<Task> tasks);

        void SaveExecutors(IEnumerable<Executor> executors);
    }
}