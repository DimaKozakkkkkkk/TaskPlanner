﻿// Файл: TaskPlanner.BLL/Services/ProjectManager.cs
// ВЕРСІЯ 2.0 (Підтримує багатьох виконавців)

using TaskPlanner.BLL.Enums;
using TaskPlanner.BLL.Interfaces;
using TaskPlanner.BLL.Models;
using System;
using System.Collections.Generic;
using System.Linq;

// Псевдоніми для уникнення конфліктів
using Task = TaskPlanner.BLL.Models.Task;
using TaskStatus = TaskPlanner.BLL.Enums.TaskStatus;

namespace TaskPlanner.BLL.Services
{
    public class ProjectManager
    {
        private readonly IRepository _repository;
        private List<Executor> _executors;
        private List<Task> _tasks;

        public ProjectManager(IRepository repository)
        {
            _repository = repository;
            try
            {
                _executors = _repository.GetAllExecutors().ToList();
                _tasks = _repository.GetAllTasks().ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"ПОМИЛКА завантаження даних: {ex.Message}");
                _executors = new List<Executor>();
                _tasks = new List<Task>();
            }
        }

        private void SaveAllData()
        {
            try
            {
                _repository.SaveExecutors(_executors);
                _repository.SaveTasks(_tasks);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"!!! КРИТИЧНА ПОМИЛКА ЗБЕРЕЖЕННЯ: {ex.Message}");
            }
        }

        private int GetNextExecutorId()
        {
            return _executors.Count == 0 ? 1 : _executors.Max(e => e.Id) + 1;
        }

        private int GetNextTaskId()
        {
            return _tasks.Count == 0 ? 1 : _tasks.Max(t => t.Id) + 1;
        }

        // === Методи для Виконавців (Вимога 1) ===

        public Executor AddExecutor(string firstName, string lastName, string position)
        {
            var newExecutor = new Executor(GetNextExecutorId(), firstName, lastName, position);
            _executors.Add(newExecutor);
            SaveAllData();
            return newExecutor;
        }

        public IEnumerable<Executor> GetAllExecutors()
        {
            return _executors;
        }

        public bool DeleteExecutor(int id)
        {
            var executor = _executors.FirstOrDefault(e => e.Id == id);
            if (executor == null)
            {
                return false;
            }

            _executors.Remove(executor);

            // ВАЖЛИВО: Оновлена логіка
            // Проходимо по всіх завданнях і видаляємо цього виконавця зі списків
            foreach (var task in _tasks)
            {
                // Метод Remove() поверне true, якщо він там був і його видалили
                if (task.ExecutorIds.Contains(id))
                {
                    task.RemoveExecutor(id);
                }
            }

            SaveAllData();
            return true;
        }

        public Executor? GetExecutorById(int id)
        {
            return _executors.FirstOrDefault(e => e.Id == id);
        }

        public void UpdateExecutor(int id, string newFirstName, string newLastName, string newPosition)
        {
            var executor = GetExecutorById(id);
            if (executor != null)
            {
                executor.UpdateInfo(newFirstName, newLastName, newPosition);
                SaveAllData();
            }
        }

        // === Методи для Завдань (Вимога 2) ===

        public Task AddTask(string title, string description, DateTime deadline)
        {
            var newTask = new Task(GetNextTaskId(), title, description, deadline);
            _tasks.Add(newTask);
            SaveAllData();
            return newTask;
        }

        public IEnumerable<Task> GetAllTasks()
        {
            return _tasks;
        }

        public Task? GetTaskById(int id)
        {
            return _tasks.FirstOrDefault(t => t.Id == id);
        }

        public bool DeleteTask(int id)
        {
            var task = GetTaskById(id);
            if (task == null)
            {
                return false;
            }
            _tasks.Remove(task);
            SaveAllData();
            return true;
        }

        public void UpdateTask(int id, string newTitle, string newDescription, DateTime newDeadline)
        {
            var task = GetTaskById(id);
            if (task != null)
            {
                task.UpdateTask(newTitle, newDescription, newDeadline);
                SaveAllData();
            }
        }

        public IEnumerable<Task> GetTasksByStatus(bool isDone)
        {
            if (isDone)
            {
                return _tasks.Where(t => t.Status == TaskStatus.Done);
            }
            else
            {
                return _tasks.Where(t => t.Status != TaskStatus.Done);
            }
        }

        // === Методи Управління (Вимога 3) ===

        // 3.1. Розподілити завдання (ОНОВЛЕНО)
        public bool AssignTaskToExecutor(int taskId, int executorId)
        {
            var task = GetTaskById(taskId);
            var executor = GetExecutorById(executorId);

            if (task == null || executor == null)
            {
                return false; // Не знайшли завдання або виконавця
            }

            // Використовуємо новий метод 'AddExecutor' з Task.cs
            bool success = task.AddExecutor(executor.Id);

            if (success)
            {
                SaveAllData(); // Зберігаємо, лише якщо щось змінилось
            }
            return success;
        }

        // 3.1. (ДОДАТКОВО) Зняти виконавця з завдання
        public bool RemoveExecutorFromTask(int taskId, int executorId)
        {
            var task = GetTaskById(taskId);
            var executor = GetExecutorById(executorId); // Перевіряємо, чи існує

            if (task == null || executor == null)
            {
                return false;
            }

            // Використовуємо новий метод 'RemoveExecutor' з Task.cs
            bool success = task.RemoveExecutor(executor.Id);
            if (success)
            {
                SaveAllData();
            }
            return success;
        }

        // 3.2. Вказати ступінь виконання
        public bool ChangeTaskStatus(int taskId, TaskStatus newStatus)
        {
            var task = GetTaskById(taskId);
            if (task == null)
            {
                return false;
            }
            task.ChangeStatus(newStatus);
            SaveAllData();
            return true;
        }

        // 3.4. Перевірка завантаженості (ОНОВЛЕНО)
        public int GetExecutorWorkload(int executorId)
        {
            var executor = GetExecutorById(executorId);
            if (executor == null)
            {
                throw new ArgumentException($"Виконавець з ID {executorId} не знайдений.");
            }

            // Рахуємо, у скількох списках ExecutorIds є цей ID, і статус не Done
            return _tasks.Count(t => t.ExecutorIds.Contains(executorId) && t.Status != TaskStatus.Done);
        }

        // 3.5. Отримання стану виконання проекту
        public string GetProjectStatus()
        {
            if (_tasks.Count == 0)
            {
                return "У проекті ще немає завдань.";
            }
            int doneTasks = _tasks.Count(t => t.Status == TaskStatus.Done);
            int totalTasks = _tasks.Count;
            double percentage = (double)doneTasks / totalTasks * 100;
            return $"Виконано {doneTasks} з {totalTasks} завдань ({percentage:F2}%).";
        }


        // === Методи Пошуку (Вимога 4) (ОНОВЛЕНО) ===

        // 4.1. Пошук завдань конкретного виконавця (ОНОВЛЕНО)
        public IEnumerable<Task> GetTasksForExecutor(int executorId)
        {
            if (GetExecutorById(executorId) == null)
            {
                throw new ArgumentException($"Виконавець з ID {executorId} не знайдений.");
            }
            // Перевіряємо, чи список ExecutorIds містить потрібний ID
            return _tasks.Where(t => t.ExecutorIds.Contains(executorId));
        }

        // 4.2. Пошук виконавців певного завдання (ОНОВЛЕНО)
        // Тепер повертає список виконавців, як ви й просили
        public IEnumerable<Executor> GetExecutorsOfTask(int taskId)
        {
            var task = GetTaskById(taskId);
            if (task == null)
            {
                throw new ArgumentException($"Завдання з ID {taskId} не знайдено.");
            }

            if (!task.ExecutorIds.Any())
            {
                return new List<Executor>(); // Повертаємо порожній список
            }

            // Шукаємо у нашому "кеші" _executors всіх, 
            // чиї ID є у списку ExecutorIds завдання
            return _executors.Where(e => task.ExecutorIds.Contains(e.Id));
        }

        // 4.3. Складний пошук (НОВИЙ МЕТОД)
        // isDone: true=Done, false=Not Done
        // isExpired: true=Expired, false=Not Expired (триває)
        public IEnumerable<Task> SearchTasks(bool isDone, bool isExpired)
        {
            IEnumerable<Task> result = _tasks;

            // 1. Фільтруємо за статусом
            if (isDone)
            {
                result = result.Where(t => t.Status == TaskStatus.Done);
            }
            else
            {
                result = result.Where(t => t.Status != TaskStatus.Done);
            }

            // 2. Фільтруємо за терміном
            if (isExpired)
            {
                result = result.Where(t => t.IsExpired()); // Протерміновані
            }
            else
            {
                result = result.Where(t => !t.IsExpired()); // "Триває" (не протерміновані)
            }

            return result;
        }

    } 
}