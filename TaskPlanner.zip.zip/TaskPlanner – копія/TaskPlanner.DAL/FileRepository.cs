﻿// Файл: TaskPlanner.DAL/FileRepository.cs
using Newtonsoft.Json;
using System.IO;
using TaskPlanner.BLL.Interfaces;
using TaskPlanner.BLL.Models;

// ОЦЕ ВИРІШЕННЯ:
// Ми кажемо, що у цьому файлі "Task" - це НАШ Task
using Task = TaskPlanner.BLL.Models.Task;

namespace TaskPlanner.DAL
{
    public class FileRepository : IRepository
    {
        private readonly string _tasksFilePath = "tasks.json";
        private readonly string _executorsFilePath = "executors.json";
        private readonly JsonSerializerSettings _settings;

        public FileRepository()
        {
            _settings = new JsonSerializerSettings
            {
                Formatting = Formatting.Indented,
                ConstructorHandling = ConstructorHandling.AllowNonPublicDefaultConstructor
            };
        }

        public IEnumerable<Executor> GetAllExecutors()
        {
            if (!File.Exists(_executorsFilePath))
            {
                return new List<Executor>();
            }
            string json = File.ReadAllText(_executorsFilePath);
            var executors = JsonConvert.DeserializeObject<List<Executor>>(json, _settings);
            return executors ?? new List<Executor>();
        }

        // Тепер C# розуміє, що це IEnumerable НАШИХ Task
        public IEnumerable<Task> GetAllTasks()
        {
            if (!File.Exists(_tasksFilePath))
            {
                return new List<Task>();
            }
            string json = File.ReadAllText(_tasksFilePath);
            // І тут він розуміє List НАШИХ Task
            var tasks = JsonConvert.DeserializeObject<List<Task>>(json, _settings);
            return tasks ?? new List<Task>();
        }

        public void SaveExecutors(IEnumerable<Executor> executors)
        {
            string json = JsonConvert.SerializeObject(executors, _settings);
            File.WriteAllText(_executorsFilePath, json);
        }

        // І тут він розуміє IEnumerable НАШИХ Task
        public void SaveTasks(IEnumerable<Task> tasks)
        {
            string json = JsonConvert.SerializeObject(tasks, _settings);
            File.WriteAllText(_tasksFilePath, json);
        }
    }
}